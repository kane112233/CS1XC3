var course_8c =
[
    [ "enroll_student", "course_8c.html#af3abbc650ef56ffff427a62dad63fc77", null ],
    [ "passing", "course_8c.html#a3f939f002e675839379b8d2dff044162", null ],
    [ "print_course", "course_8c.html#a99bf8b3f3c2d5dc7cf798ed445eaaa77", null ],
    [ "top_student", "course_8c.html#ae0130f7ef7b879c9a790ee27a5ce21b7", null ]
];