var struct__course =
[
    [ "code", "struct__course.html#ae86dc46bc4dfe126555e5560860b583f", null ],
    [ "name", "struct__course.html#a8a6f7d2171f18b5d13e86913345f381d", null ],
    [ "students", "struct__course.html#a5cf448bc80f0f8c5f23402db23d41a00", null ],
    [ "total_students", "struct__course.html#afd5e161f7cf358c13cc8aa868b462006", null ]
];